NOTE: This works for 2.0.0 Onwards! make sure to use that version if you want to use this pack!

WHAT IS THIS?

This is the Ultimate VoicePack For Wrapper Offline, it has over 1000+ voices from different TTS providers, those being.

HOW TO INSTALL THE PACK.

There's 2 folders, one which has 3 folders inside (note: do not confuse either tts.js with each other, it should go with their respective folders), This pack works for 2.0.0 onwards

Replace "realFileUtil.js" in wrapper-offline-win32-x64/resources/app/utils with the one in the pack.

Replace "tts.js" in wrapper-offline-win32-x64/resources/app/wrapper/controllers with the one in the pack.

Replace "tts.js" in wrapper-offline-win32-x64/resources/app/wrapper/models with the one in the pack.

and then replace "voices.json" in wrapper-offline-win32-x64/resources/app/wrapper/data with the one in the pack 

Close wrapper, open it back up, go to the videomaker, click on text to speech and it should be present and working.